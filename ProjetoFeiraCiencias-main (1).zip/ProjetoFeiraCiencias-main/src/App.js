import { Rotas } from './Rotas';
import './App.css';

const App = () => {
  return (
    <Rotas />
  );
};

export default App; 
