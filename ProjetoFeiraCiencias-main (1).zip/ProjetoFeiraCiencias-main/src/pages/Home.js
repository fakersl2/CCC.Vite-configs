import React from 'react'

const Home = () => {
    <h1>Teste Home Page</h1>
};

export default Home;
